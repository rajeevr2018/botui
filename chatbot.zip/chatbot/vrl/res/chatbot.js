$(document).ready(function(){
    

    function getBrowserName(){
        // Opera 8.0+
        var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
    
        // Firefox 1.0+
        var isFirefox = typeof InstallTrigger !== 'undefined';
    
        // Safari 3.0+ "[object HTMLElementConstructor]"
        var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);
    
        // Internet Explorer 6-11
        var isIE = /*@cc_on!@*/false || !!document.documentMode;
    
        // Edge 20+
        var isEdge = !isIE && !!window.StyleMedia;
    
        // Chrome 1+
        var isChrome = !!window.chrome && !!window.chrome.webstore;
    
        if(isChrome)
        {
          return "Google Chrome";
        }

        if(isFirefox)
        {
          return "Firefox";
        }

        if(isSafari)
        {
          return "Safari";
        }

        if(isIE)
        {
          return "Internet Explorer";
        }
        
        if(isEdge)
        {
          return "Edge";
        }
    }


   // $("#guestPhone").intlTelInput();

   $(".logo_chatbot").on("click",function(){
       window.parent.postMessage({message: 'closeWindow'}, '*');
       //parent.closeChatWindow();
   });

    function get_clean_alphanum_string($string){
       return $string.replace(/[^\w\s]/gi, '');
    }

    function nextStep(step,ad){
        $(".stepWrap").hide();
        $(step).show();
        $(".advwrp").removeClass("active");
        $(ad).addClass("active");
    }
   
    
    $("#submitQuery-noac button").click(function(){
        var queryInput = $("#queryInput").val();        
        var sanitizedInput = get_clean_alphanum_string(queryInput);
        $("#queryInput").val(sanitizedInput);
        if(queryInput === ""){
            $("#queryInput").addClass("hasError");
        }else{
            $("#queryInput").removeClass("hasError");
            $("#submitQuery-noac").hide();
            //if(parent.location.href.split("/").indexOf("demo") > 0){
                window.parent.postMessage({message: 'resizeFrame'}, '*');
                //parent.resizeFrame(515);
            // }
            
             $("#cb-step-two_b").show();
             $(".advwrp").removeClass("active");
             $(".adwrap-b").addClass("active");
        }
    });

    //default step to be active
    nextStep("#cb-step-two",".adwrap-a");
    //Query submit action
    var quereyResults;
    //var setUserRecordAPI = "testdata.json";
    var setUserRecordAPI = "/botAPI/SetUserRecord/";    
    var setUserRecordBody = {
        "username": "",
        "country_code": "",
        "phone_number": "",
        "query": "",
        "app_name": "browser",
        "partner": "vrl",
        "channel": "bus",
        "location": "",
        "ip_address": "",
        "language": "en",
        "os": "",
        "browser": "",
        "device_token":""
    };
    var setQuestionRecordAPI = "/botAPI/SetQuestionRecord/";
    var setQuestionRecordBody = {
        "query": "",
        "app_name": "browser",
        "partner": "vrl",
        "channel": "bus",
        "selected_question":"",
        "browser": ""
    }; 
    var getQuestionHitAPI = "/getQuestionHit/";
    var getQuestionHitBody = {
        "session_id":"",
        "question_id":"",
        "selected_question":""
    };   
    
    //send non of the above index
    function noneOfTheAbove(queryData, botAPI){
        nextStep("#cb-step-four",".adwrap-c");
        $.ajax({            
            url: botAPI,
            method: "POST",
            data:JSON.stringify(queryData),
            beforeSend: function (xhr) {
                xhr.setRequestHeader('authkey', '9a12ab538-9ffe-49a5-7124-bc7d61123f4ab');
                xhr.setRequestHeader('content-type', 'application/json');
            }
          })
          .done(function( data ) {
            //nextStep("#cb-step-four",".adwrap-c");            
        });
    }
    //getQueryAnswer
    function getAnswer(queryData,apiURL){
        $(".apierror").hide();
        $.ajax({            
            url: apiURL,
            method: "POST",
            data:JSON.stringify(queryData),
            beforeSend: function (xhr) {
                xhr.setRequestHeader('authkey', '9a12ab538-9ffe-49a5-7124-bc7d61123f4ab');
                xhr.setRequestHeader('content-type', 'application/json');
                $("#loadingGif").show();
            }
          })
          .done(function( data ) {
            $(".query-results").show();
            $("#loadingGif").hide();
            quereyResults = data.results;
            nextStep("#cb-step-three",".adwrap-b");
            setQuestionRecordBody.session_id = data.session_id;
            getQuestionHitBody.session_id = data.session_id;
            getQuestionHitBody.question_id = data.question_id;
            if(quereyResults){
                showResult(quereyResults);
            }
        })
        .fail(function() {
            $(".query-results").hide();
            $(".no-q-results").show();
            $("#loadingGif").hide();
            $(".apierror").show().delay(3000).fadeOut('fast');
        });
    }
    
    function showResult(quereyResults){
        $("#failedMessage").hide();
        $("#nomatchingresults").hide();
        if(quereyResults.AnswerToUser){
            $("#nomatchingresults").show();
            $("#nomatchingresults .message").html(quereyResults.AnswerToUser);
            $("#resultsoptiontitle, .cb-query-types").hide();
        }else if(quereyResults.errno){
            $("#failedMessage").show();
        }else{
            $("#nomatchingresults").hide();
            $("#resultsoptiontitle,.cb-query-types").show();
            quereyResults.Answer.push('Reach out to us using CoRover Connect App for any unanswered query: http://onelink.to/98hway <br> OR<br> You can also reach us at feedback@vrllogistics.com or call our customer care at +91-836-230-7300');
            $(".cb-query-types li").remove();
            $.each( quereyResults.Question[0], function( key, val ) {
                 var index = key;
                 $(".cb-query-types").append('<li index="'+index+'"><span class="left"><em class="glyphicon glyphicon-play-circle"></em></span><span class="right">'+val+'</span></li>')
                 
            });            
        }
    }

    // $("#queryInput2").keypress(function (e) {
    //     if(e.which == 13) {
    //         $("#submitQuery2").click();
    //         e.preventDefault();
    //     }
    // });
    // $("#queryInput").keypress(function (e) {
    //     if(e.which == 13) {
    //         $("#submitQuery-noac button").click();
    //         e.preventDefault();
    //     }
    // });

    $('#queryInput, #queryInput2').keydown(function (e) {
        if (e.keyCode === 13 && e.ctrlKey) {
            $(this).val(function(i,val){
                return val + "\n";
            });            
        }
        resizeInputFeild(this);
    }).keypress(function(e){
        if (e.keyCode === 13 && !e.ctrlKey) {
            $("#submitQuery-noac button").click();
            return false;  
        } 
        resizeInputFeild(this);
    });
    
    $('#queryInput, #queryInput2').change(function(){
        resizeInputFeild(this);
    });

    function resizeInputFeild(ob){
        $(ob).css("height","34px"); 
        $(ob).css("height",Math.min(ob.scrollHeight+2, 80) + "px");
    }

    //validate input fields
    var isValidInput = false;
    var isValid = function(){
        $(".required").each(function(){
            var type = $(this).attr("for");
            switch (type) {
                case "textarea":
                    if($(this).val().length < 1){
                        $(this).addClass("errorMsg");
                        $(".validation-message", $(this).parent()).show();
                        $(this).focus();
                        isValidInput = false;
                        return false;
                    }else{
                        $(this).removeClass("errorMsg");
                        $(".validation-message", $(this).parent()).hide();
                    }
                     break;
                case "text":
                    if($(this).val().length < 1){
                        $(this).addClass("errorMsg");
                        $(".validation-message", $(this).parent()).show();
                        $(this).focus();
                        isValidInput = false;
                        return false;
                    }else{
                        $(this).removeClass("errorMsg");
                        $(".validation-message", $(this).parent()).hide();
                    }
                    break;    
                case "number":
                    if($(this).val().length < 10){
                        $($(this).parent()).addClass("errorMsg");
                        $(".validation-message", $(this).parent().parent()).show();
                        $(this).focus();
                        isValidInput = false;
                        return false;
                    }else{
                        $($(this).parent()).removeClass("errorMsg");
                        $(".validation-message", $(this).parent().parent()).hide();
                    }
                    break; 
                case "countrycode":                    
                    var c_code = $(this).val();
                    if($(this).val().length < 1){
                        $($(this).parent()).addClass("errorMsg");
                        $(".validation-message", $(this).parent().parent()).show();
                        $(this).focus();
                        isValidInput = false;
                        return false;
                    }else{
                        $($(this).parent()).removeClass("errorMsg");
                        $(".validation-message", $(this).parent().parent()).hide();
                    }
                    break;        
                case "checkbox":
                    if($("input[id='cb-tc']:checked").val() !== "on"){
                        $(".validation-message", $(this).parent()).show();
                        $(this).focus();
                        isValidInput = false;
                        return false;
                    }else{
                        $(".validation-message", $(this).parent()).hide();
                    }
                    break;
                default:
                    $(".validation-message", $(this).parent()).hide();
                    isValidInput = true;
                    return true;                    
            }
        });
   }
   //validate input fields ends

    $("#submitQuery").click(function(){
        var queryInput = $("#queryInput").val();        
        $("#queryInput").val(get_clean_alphanum_string(queryInput));
        queryInput = $("#queryInput").val();
         var c_code = $("#countryCode").val();
         var phone = $("#guestPhone").val();
         var username = $("#guestName").val();    
         var browserName = getBrowserName();
        //set input values to query object
        setQuestionRecordBody.query = queryInput;
        setUserRecordBody.query = queryInput;
        setUserRecordBody.username = username;
        setUserRecordBody.phone_number = phone;
        setUserRecordBody.country_code = c_code;
        setUserRecordBody.browser = browserName;
        isValid();
        if(isValidInput){
            getAnswer(setUserRecordBody,setUserRecordAPI);
        }    
    });
    

    $("#submitQuery2").click(function(){        
        if(queryInput === ""){
            $("#queryInput2").addClass("errorMsg");
            $("#queryInput2").focus();
        }else{
            $("#queryInput2").removeClass("errorMsg");
            $("#queryInput2").trigger('blur'); 
            var queryInput = $("#queryInput2").val();        
            $("#queryInput2").val(get_clean_alphanum_string(queryInput));
            queryInput = $("#queryInput2").val(); 
            setQuestionRecordBody.query = queryInput;
            setQuestionRecordBody.selected_question = "";
            getAnswer(setQuestionRecordBody,setQuestionRecordAPI);
        }
    });

    $( "ul.cb-query-types" ).on( "click", "li", function() {
        //nextStep("#cb-step-four");
        $("#cb-step-four").addClass("active");
        var curIndex = $(this).attr('index');
        $('.selected-query-item').html(quereyResults.Question[0][curIndex]);
        $('.query-answer').html(quereyResults.Answer[curIndex]);
        $(".query-answer").linkify();
        if(curIndex === "2"){
            //getQuestionHitBody.selected_question = $("span.right", $(this)).text();
            setQuestionRecordBody.selected_question = "3";
            noneOfTheAbove(setQuestionRecordBody,setQuestionRecordAPI);
        }else{
          nextStep("#cb-step-four",".adwrap-c");            
        }        
    });
    
    $("#cb-step-three .query-none").click(function(){
        nextStep("#cb-step-five",".adwrap-c");
    });

    $("a.back").click(function(){
        $("#cb-step-four").removeClass("active");
        nextStep("#cb-step-three",".adwrap-b");
    });

    $(document).keyup(function (e) {
        if(e.which == 8 && $("#cb-step-four").hasClass("active")) {
            $("#cb-step-four").removeClass("active");
            nextStep("#cb-step-three",".adwrap-b");
        }
    });


    $(".logo_chatbot").click(function(){
        //nextStep("#cb-step-two");
        //$("#queryInput").val("");
    });
    $(".reset-query").click(function(){
        nextStep("#cb-step-two");
    });

    $("#tncLink").click(function(){
        $("#term_wrap").show();
    });

    $("#privacyLink").click(function(){
        $("#privacy_wrap").show();
        $("#privacy_wrap").linkify();
    });
 

//############################
  var productNames = new Array();
  var productIds = new Object();
  $.getJSON( 'res/data/faq-vrl.json', null,
          function ( jsonData )
          {
              $.each( jsonData, function ( index, product )
              {
                  productNames.push( product.name );
                  productIds[product.name] = product.id;
              } );
              $( '#queryInput' ).typeahead( { source:productNames } );
              $( '#queryInput2' ).typeahead( { source:productNames } );
          });

//############################

});

function closeMe(id){
    $(id).hide();
}

