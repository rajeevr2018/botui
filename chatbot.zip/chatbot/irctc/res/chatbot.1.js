$(document).ready(function(){
    if(parent.location.href.split("/").indexOf("cb") < 0){
       // parent.resizeFrame(250);
    }

    function get_clean_alphanum_string($string) 
    {
       return $string.replace(/[^\w\s]/gi, '');
    }

    function nextStep(step){
        $(".stepWrap").hide();
        $(step).show();
    }

    $("#submitQuery-noac button").click(function(){
        var queryInput = $("#queryInput").val();
        var sanitizedInput = get_clean_alphanum_string(queryInput);
        $("#queryInput").val(sanitizedInput);
        if(queryInput === ""){
            $("#queryInput").addClass("hasError");
        }else{
            $("#queryInput").removeClass("hasError");
            $("#submitQuery-noac").hide();
            if(parent.location.href.split("/").indexOf("cb") < 0){
                parent.resizeFrame(385);
             }
            
             $("#cb-step-two_b").show();
        }
    });

    //default step to be active
    nextStep("#cb-step-two");
    //Query submit action
    var quereyResults;
    //var botAPI = //url: "corover/getQuestions/",
    //var botAPI = "getQuestions";
    function getQueryResult(queryInput){
        if(true){
            $("#loadingGif").show();
            $.ajax({
                method: "POST",
                url: "http://54.91.29.57:12350/parse",
                data:'{"q":"'+queryInput+'", "partner":"irctc"}'
              })
              .done(function( data ) {
                $(".query-results").show();
                $("#loadingGif").hide();
                quereyResults = data;
                quereyResults.Answer.push('You can reach us at <a href="mailto:care@irctc.co.in">care@irctc.co.in</a>. Do contact us at 24/7 Hrs. Customer support at 011-39340000');
                quereyResults.Question.push("None of the Above") ;
                nextStep("#cb-step-three");
                $("#queryInput2").val(queryInput);
                $(".cb-query-types li").remove();
                 $.each( quereyResults.Question, function( key, val ) {
                     $(".cb-query-types").append('<li index="'+key+'"><span class="left"><em class="glyphicon glyphicon-play-circle"></em></span><span class="right">'+val+'</span></li>')
                 });
            })
            .fail(function() {
                $(".query-results").hide();
                $(".no-q-results").show();
                $("#loadingGif").hide();
                if($("#queryInput").val() ===""){
                    $("#queryInput").addClass("hasError");
                }
            });
            

            $(".cbtcwrap").removeClass("errorMsgTc");
        }else{
            $(".cbtcwrap").addClass("errorMsgTc");
        }
    }
    
    $("#queryInput2").keypress(function (e) {
        if(e.which == 13) {
            $("#submitQuery2").click();
            e.preventDefault();
        }
    });
    $("#queryInput").keypress(function (e) {
        if(e.which == 13) {
            $("#submitQuery-noac button").click();
            e.preventDefault();
        }
    });

    $("#submitQuery").click(function(){
        var queryInput = $("#queryInput").val();        
        $("#queryInput").val(get_clean_alphanum_string(queryInput));
        queryInput = $("#queryInput").val();    
        getQueryResult(queryInput);
    });

    $("#submitQuery2").click(function(){
        var queryInput = $("#queryInput2").val();
        if(queryInput === ""){
            $("#queryInput2").addClass("errorMsgTc");
        }else{
            $("#queryInput2").removeClass("errorMsgTc");
            var queryInput = $("#queryInput2").val();        
            $("#queryInput2").val(get_clean_alphanum_string(queryInput));
            queryInput = $("#queryInput2").val(); 
            getQueryResult(queryInput);
        }
    });

    $( "ul.cb-query-types" ).on( "click", "li", function() {
        nextStep("#cb-step-four");
        var curIndex = $(this).attr('index');
        $('.selected-query-item').html(quereyResults.Question[curIndex]);
        $('.query-answer').html(quereyResults.Answer[curIndex]);
        //console.log(quereyResults.Answer[curIndex]);
    });
    
    $("#cb-step-three .query-none").click(function(){
        nextStep("#cb-step-five");
    });

    $("a.back").click(function(){
        nextStep("#cb-step-three");
        $('input[name="queryType"]').prop('checked', false);
    });

    $(".logo_chatbot").click(function(){
        nextStep("#cb-step-two");
        $("#queryInput").val("");
    });
    $(".reset-query").click(function(){
        nextStep("#cb-step-two");
    });
});