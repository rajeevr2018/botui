  var btn = document.getElementById("chatbotbtn");
  
  var myVar = setInterval(shakeIcon, 3000);

  function shakeIcon(){
    btn.classList.toggle("shakeMe");
  }

  btn.addEventListener("click", openChatBot);
  document.getElementById("closeme").addEventListener("click",closeChatWindow);
  var chatbotframewindow = document.getElementById("chatbotwindow");
function openChatBot() {
    document.getElementById("cb-wrap").style.display="block";
    //document.getElementById("cb-wrap").classList.add("mystyle");
    document.getElementById("cb-wrap").style.display="block";
    var cbBoxHeight = document.getElementById('cb-wrap').style.height.split("px")[0];
    // if(cbBoxHeight === "385"){
    //   resizeFrame(250);
    // }
    //var iframe = document.getElementById('chatbotwindow');
    //iframe.src = iframe.src;

    if((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1)){
      document.getElementById("cb-wrap").style.width="99%";
      //document.getElementById("cb-wrap").style.height="90%";
      document.getElementById("cb-wrap").style.right="0px";
    }
}
function closeChatWindow(){
  //resizeFrame(250);
	document.getElementById("cb-wrap").style.display="none";
}
this.closeChatWindow = function(){
  //resizeFrame(250);
	document.getElementById("cb-wrap").style.display="none";
}

this.resizeFrame = function(ht){
  document.getElementById('cb-wrap').style.height=ht+"px"
}

this.getPartnerConfig = function(){
  var botConfig = new Object()
  botConfig.name =  chatbotframewindow.getAttribute("for");
}

window.addEventListener('message', function(event) { 

  // IMPORTANT: Check the origin of the data! 
  if (~event.origin.indexOf('https://assistant.corover.mobi')) { 
      if(event.data.message === "closeWindow" ){
        closeChatWindow();
      }
      if(event.data.message === "resizeFrame" ){
        resizeFrame(525);
      }
  } else { 
      return; 
  } 
}); 
